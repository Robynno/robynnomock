export default [
	[
		"City/Town"
	],
	[
		"Rhode Island"
	],
	[
		"Barrington"
	],
	[
		"Bristol"
	],
	[
		"Burrillville"
	],
	[
		"Central Falls"
	],
	[
		"Charlestown"
	],
	[
		"Coventry"
	],
	[
		"Cranston"
	],
	[
		"Cumberland"
	],
	[
		"East Greenwich"
	],
	[
		"East Providence"
	],
	[
		"Exeter"
	],
	[
		"Foster"
	],
	[
		"Glocester"
	],
	[
		"Hopkinton"
	],
	[
		"Jamestown"
	],
	[
		"Johnston"
	],
	[
		"Lincoln"
	],
	[
		"Little Compton"
	],
	[
		"Middletown"
	]
];