import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8612ede7"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8612ede7"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=c4873af3"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import "/src/styles/index.css?t=1697174494758";
import App from "/src/components/App.tsx?t=1697224057500";
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(/* @__PURE__ */ jsxDEV(React.StrictMode, { children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
  fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/index.tsx",
  lineNumber: 11,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/index.tsx",
  lineNumber: 10,
  columnNumber: 13
}, this));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYUk7QUFiSixPQUFPQSxXQUFXO0FBQ2xCLE9BQU9DLGNBQWM7QUFDckIsT0FBTztBQUNQLE9BQU9DLFNBQVM7QUFLaEIsTUFBTUMsT0FBT0YsU0FBU0csV0FDcEJDLFNBQVNDLGVBQWUsTUFBTSxDQUNoQztBQUNBSCxLQUFLSSxPQUNILHVCQUFDLE1BQU0sWUFBTixFQUNDLGlDQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUFJLEtBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUVBLENBQ0YiLCJuYW1lcyI6WyJSZWFjdCIsIlJlYWN0RE9NIiwiQXBwIiwicm9vdCIsImNyZWF0ZVJvb3QiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwicmVuZGVyIl0sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgUmVhY3RET00gZnJvbSAncmVhY3QtZG9tL2NsaWVudCc7XG5pbXBvcnQgJy4vc3R5bGVzL2luZGV4LmNzcyc7XG5pbXBvcnQgQXBwIGZyb20gJy4vY29tcG9uZW50cy9BcHAnO1xuXG4vLyBUaW0gcmVtb3ZlZCBzb21lIGJvaWxlcnBsYXRlIHRvIGtlZXAgdGhpbmdzIHNpbXBsZS5cbi8vIFdlJ3JlIHVzaW5nIGFuIG9sZGVyIHZlcnNpb24gb2YgUmVhY3QgaGVyZS4gXG5cbmNvbnN0IHJvb3QgPSBSZWFjdERPTS5jcmVhdGVSb290KFxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncm9vdCcpIGFzIEhUTUxFbGVtZW50XG4pO1xucm9vdC5yZW5kZXIoXG4gIDxSZWFjdC5TdHJpY3RNb2RlPlxuICAgIDxBcHAgLz5cbiAgPC9SZWFjdC5TdHJpY3RNb2RlPlxuKTsiXSwiZmlsZSI6Ii9Vc2Vycy9zZWVoYW5haHRhbmcvRGVza3RvcC9jcy9jczMyL21vY2stcmplY3JvaTEtc3Rhbmc1Mi9zcmMvaW5kZXgudHN4In0=