import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLHistory.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8612ede7"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css?t=1697174494758";
export function REPLHistory(props) {
  function makeTableHTML(tableData) {
    const tableRows = tableData.map((rowData) => `<tr>${rowData.map((cellData) => `<td>${cellData}</td>`).join("")}</tr>`);
    return `<table border="1">${tableRows.join("")}</table>`;
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-history", children: props.history.map((entry) => /* @__PURE__ */ jsxDEV("div", { children: props.mode ? /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("p", { children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "output" }, void 0, false, {
        fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLHistory.tsx",
        lineNumber: 19,
        columnNumber: 20
      }, this),
      ": "
    ] }, void 0, true, {
      fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLHistory.tsx",
      lineNumber: 19,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "center-table", dangerouslySetInnerHTML: {
      __html: makeTableHTML(entry.output)
    } }, void 0, false, {
      fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLHistory.tsx",
      lineNumber: 20,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLHistory.tsx",
    lineNumber: 18,
    columnNumber: 27
  }, this) : /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("p", { children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "command" }, void 0, false, {
        fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLHistory.tsx",
        lineNumber: 25,
        columnNumber: 19
      }, this),
      ": ",
      entry.command,
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLHistory.tsx",
        lineNumber: 26,
        columnNumber: 19
      }, this),
      /* @__PURE__ */ jsxDEV("strong", { children: "output" }, void 0, false, {
        fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLHistory.tsx",
        lineNumber: 27,
        columnNumber: 19
      }, this),
      ": "
    ] }, void 0, true, {
      fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLHistory.tsx",
      lineNumber: 24,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "center-table", dangerouslySetInnerHTML: {
      __html: makeTableHTML(entry.output)
    } }, void 0, false, {
      fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLHistory.tsx",
      lineNumber: 28,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLHistory.tsx",
    lineNumber: 23,
    columnNumber: 24
  }, this) }, entry.command, false, {
    fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLHistory.tsx",
    lineNumber: 17,
    columnNumber: 37
  }, this)) }, void 0, false, {
    fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLHistory.tsx",
    lineNumber: 16,
    columnNumber: 10
  }, this);
}
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JtQjtBQS9CbkIsT0FBTyxvQkFBb0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFhcEIsZ0JBQVNBLFlBQVlDLE9BQTBCO0FBQ2xELFdBQVNDLGNBQWNDLFdBQXNCO0FBQzNDLFVBQU1DLFlBQVlELFVBQVVFLElBQ3pCQyxhQUNFLE9BQU1BLFFBQ0pELElBQUtFLGNBQWMsT0FBTUEsUUFBUyxPQUFNLEVBQ3hDQyxLQUFLLEVBQUUsQ0FBRSxPQUNoQjtBQUVBLFdBQVEscUJBQW9CSixVQUFVSSxLQUFLLEVBQUUsQ0FBRTtBQUFBLEVBQ2pEO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ1pQLGdCQUFNUSxRQUFRSixJQUFLSyxXQUNsQix1QkFBQyxTQUNFVCxnQkFBTVUsT0FDTCx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsT0FBRTtBQUFBLDZCQUFDLFlBQU8sc0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFjO0FBQUEsTUFBUztBQUFBLFNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEI7QUFBQSxJQUM1Qix1QkFBQyxTQUNDLFdBQVUsZ0JBQ1YseUJBQXlCO0FBQUEsTUFDdkJDLFFBQVFWLGNBQWNRLE1BQU1HLE1BQU07QUFBQSxJQUNwQyxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJSTtBQUFBLE9BTk47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBLElBRUEsdUJBQUMsU0FDQztBQUFBLDJCQUFDLE9BQ0M7QUFBQSw2QkFBQyxZQUFPLHVCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BQVM7QUFBQSxNQUFHSCxNQUFNSTtBQUFBQSxNQUNqQyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLE1BQ0gsdUJBQUMsWUFBTyxzQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWM7QUFBQSxNQUFTO0FBQUEsU0FIekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUcyQjtBQUFBLElBQzNCLHVCQUFDLFNBQ0MsV0FBVSxnQkFDVix5QkFBeUI7QUFBQSxNQUN2QkYsUUFBUVYsY0FBY1EsTUFBTUcsTUFBTTtBQUFBLElBQ3BDLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlJO0FBQUEsT0FUTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBV0EsS0F2Qk1ILE1BQU1JLFNBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5QkEsQ0FDRCxLQTVCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkJBO0FBRU47QUFBQ0MsS0E1Q2VmO0FBQVcsSUFBQWU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJFUExIaXN0b3J5IiwicHJvcHMiLCJtYWtlVGFibGVIVE1MIiwidGFibGVEYXRhIiwidGFibGVSb3dzIiwibWFwIiwicm93RGF0YSIsImNlbGxEYXRhIiwiam9pbiIsImhpc3RvcnkiLCJlbnRyeSIsIm1vZGUiLCJfX2h0bWwiLCJvdXRwdXQiLCJjb21tYW5kIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRVBMSGlzdG9yeS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICcuLi9zdHlsZXMvbWFpbi5jc3MnO1xuXG5leHBvcnQgaW50ZXJmYWNlIEVudHJ5IHtcbiAgICBjb21tYW5kOiBzdHJpbmc7XG4gICAgb3V0cHV0OiBzdHJpbmdbXVtdOyAvLyBvdXRwdXQgY2FuIGJlIGVpdGhlciBvciBcbn1cblxuaW50ZXJmYWNlIFJFUExIaXN0b3J5UHJvcHN7XG4gICAgaGlzdG9yeTogRW50cnlbXSxcbiAgICBtb2RlOiBib29sZWFuXG59XG5cblxuZXhwb3J0IGZ1bmN0aW9uIFJFUExIaXN0b3J5KHByb3BzIDogUkVQTEhpc3RvcnlQcm9wcykge1xuICAgIGZ1bmN0aW9uIG1ha2VUYWJsZUhUTUwodGFibGVEYXRhOnN0cmluZ1tdW10pIHtcbiAgICAgIGNvbnN0IHRhYmxlUm93cyA9IHRhYmxlRGF0YS5tYXAoXG4gICAgICAgIChyb3dEYXRhKSA9PlxuICAgICAgICAgIGA8dHI+JHtyb3dEYXRhXG4gICAgICAgICAgICAubWFwKChjZWxsRGF0YSkgPT4gYDx0ZD4ke2NlbGxEYXRhfTwvdGQ+YClcbiAgICAgICAgICAgIC5qb2luKFwiXCIpfTwvdHI+YFxuICAgICAgKTtcblxuICAgICAgcmV0dXJuIGA8dGFibGUgYm9yZGVyPVwiMVwiPiR7dGFibGVSb3dzLmpvaW4oXCJcIil9PC90YWJsZT5gO1xuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlcGwtaGlzdG9yeVwiPlxuICAgICAgICB7cHJvcHMuaGlzdG9yeS5tYXAoKGVudHJ5KSA9PiAoXG4gICAgICAgICAgPGRpdiBrZXk9e2VudHJ5LmNvbW1hbmR9PlxuICAgICAgICAgICAge3Byb3BzLm1vZGUgPyAoXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPHA+PHN0cm9uZz5vdXRwdXQ8L3N0cm9uZz46IDwvcD5cbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjZW50ZXItdGFibGVcIlxuICAgICAgICAgICAgICAgICAgZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw9e3tcbiAgICAgICAgICAgICAgICAgICAgX19odG1sOiBtYWtlVGFibGVIVE1MKGVudHJ5Lm91dHB1dCksXG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+Y29tbWFuZDwvc3Ryb25nPjoge2VudHJ5LmNvbW1hbmR9XG4gICAgICAgICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+b3V0cHV0PC9zdHJvbmc+OiA8L3A+XG4gICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY2VudGVyLXRhYmxlXCJcbiAgICAgICAgICAgICAgICAgIGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MPXt7XG4gICAgICAgICAgICAgICAgICAgIF9faHRtbDogbWFrZVRhYmxlSFRNTChlbnRyeS5vdXRwdXQpLFxuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkpfVxuICAgICAgPC9kaXY+XG4gICAgKTtcbn0iXSwiZmlsZSI6Ii9Vc2Vycy9zZWVoYW5haHRhbmcvRGVza3RvcC9jcy9jczMyL21vY2stcmplY3JvaTEtc3Rhbmc1Mi9zcmMvY29tcG9uZW50cy9SRVBMSGlzdG9yeS50c3gifQ==