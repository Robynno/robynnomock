import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8612ede7"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css?t=1697174494758";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=8612ede7"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/ControlledInput.tsx";
import { jsonMap, mockedJson } from "/mock-data/mockedJson.ts?t=1697224057500";
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [filepath, setFilepath] = useState("");
  const newEntry = {
    command: commandString,
    output: [[""]]
  };
  function handleSubmit(commandString2) {
    const words = commandString2.split(" ");
    if (words[0].toLowerCase() === "mode") {
      handleMode(words);
    } else if (words[0].toLowerCase() === "load_file") {
      handleLoad(words);
    } else if (words[0].toLowerCase() === "view") {
      handleView();
    } else if (words[0].toLowerCase() === "search") {
      handleSearch(words);
    } else {
      newEntry.output = [["Please enter a valid command."]];
    }
    props.setHistory([...props.history, newEntry]);
    setCommandString("");
  }
  function handleMode(words) {
    if (!words[1]) {
      newEntry.output = [["Please enter mode."]];
    } else if (words[1] === "brief") {
      props.setMode(true);
      newEntry.output = [["Mode changed to " + words[1] + "."]];
    } else if (words[1] == "verbose") {
      props.setMode(false);
      newEntry.output = [["Mode changed to " + words[1] + "."]];
    } else {
      newEntry.output = [["Please enter a valid command."]];
    }
  }
  function handleLoad(words) {
    const filePath = words[1];
    if (!words[1]) {
      newEntry.output = [["Please enter filepath."]];
      return;
    }
    const mockedResponse = mockedJson[words[1]];
    if (mockedResponse) {
      newEntry.output = [["CSV file: " + filePath + " loaded successfully"]];
      setFilepath(filePath);
    } else {
      newEntry.output = [["Error: " + filePath + " cannot be loaded"]];
    }
  }
  function handleView() {
    if (filepath) {
      newEntry.output = mockedJson[filepath];
    } else {
      newEntry.output = [["Need to load first."]];
    }
  }
  function handleSearch(words) {
    if (!words[1] || !words[2]) {
      newEntry.output = [["Please enter column and value."]];
      return;
    }
    const key = JSON.stringify([words[1], words[2]]);
    if (filepath) {
      const mockedMap = jsonMap[filepath];
      if (key in mockedMap) {
        if (mockedMap[key].length == 0) {
          newEntry.output = [["Value " + words[2] + " not found in column " + words[1]]];
        } else {
          newEntry.output = mockedMap[key];
        }
      } else {
        newEntry.output = [["Invalid inputs " + words[1] + ", " + words[2] + " for search."]];
      }
    } else {
      newEntry.output = [["Need to load first before searching."]];
    }
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
        fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLInput.tsx",
        lineNumber: 120,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLInput.tsx",
        lineNumber: 121,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLInput.tsx",
      lineNumber: 119,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => handleSubmit(commandString), children: "Submit" }, void 0, false, {
      fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLInput.tsx",
      lineNumber: 123,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLInput.tsx",
    lineNumber: 114,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "ll5ZT0Syt5lFhn32lhOVxSgvm5k=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0lROzs7Ozs7Ozs7Ozs7Ozs7OztBQWhJUixPQUFPO0FBQ1AsU0FBbUNBLGdCQUFlO0FBQ2xELFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxTQUFTQyxrQkFBa0I7QUFlN0IsZ0JBQVNDLFVBQVVDLE9BQXdCO0FBQUFDLEtBQUE7QUFHaEQsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSVIsU0FBaUIsRUFBRTtBQUM3RCxRQUFNLENBQUNTLFVBQVVDLFdBQVcsSUFBSVYsU0FBaUIsRUFBRTtBQUNuRCxRQUFNVyxXQUFXO0FBQUEsSUFDZkMsU0FBU0w7QUFBQUEsSUFDVE0sUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQUEsRUFDZjtBQUdBLFdBQVNDLGFBQWFQLGdCQUF1QjtBQUUzQyxVQUFNUSxRQUFRUixlQUFjUyxNQUFNLEdBQUc7QUFHckMsUUFBSUQsTUFBTSxDQUFDLEVBQUVFLFlBQVksTUFBTSxRQUFRO0FBQ3JDQyxpQkFBV0gsS0FBSztBQUFBLElBQ2xCLFdBQVdBLE1BQU0sQ0FBQyxFQUFFRSxZQUFZLE1BQU0sYUFBYTtBQUNqREUsaUJBQVdKLEtBQUs7QUFBQSxJQUNsQixXQUFXQSxNQUFNLENBQUMsRUFBRUUsWUFBWSxNQUFNLFFBQVE7QUFDNUNHLGlCQUFXO0FBQUEsSUFDYixXQUFXTCxNQUFNLENBQUMsRUFBRUUsWUFBWSxNQUFNLFVBQVU7QUFDOUNJLG1CQUFhTixLQUFLO0FBQUEsSUFDcEIsT0FBTztBQUNMSixlQUFTRSxTQUFTLENBQUMsQ0FBQywrQkFBK0IsQ0FBQztBQUFBLElBQ3REO0FBQ0FSLFVBQU1pQixXQUFXLENBQUMsR0FBR2pCLE1BQU1rQixTQUFTWixRQUFRLENBQUM7QUFDN0NILHFCQUFpQixFQUFFO0FBQUEsRUFDckI7QUFFQSxXQUFTVSxXQUFXSCxPQUFpQjtBQUNuQyxRQUFJLENBQUNBLE1BQU0sQ0FBQyxHQUFHO0FBQ2JKLGVBQVNFLFNBQVMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDO0FBQUEsSUFDM0MsV0FBV0UsTUFBTSxDQUFDLE1BQU0sU0FBUztBQUMvQlYsWUFBTW1CLFFBQVEsSUFBSTtBQUNsQmIsZUFBU0UsU0FBUyxDQUFDLENBQUMscUJBQXFCRSxNQUFNLENBQUMsSUFBSSxHQUFHLENBQUM7QUFBQSxJQUMxRCxXQUFXQSxNQUFNLENBQUMsS0FBSyxXQUFXO0FBQ2hDVixZQUFNbUIsUUFBUSxLQUFLO0FBQ25CYixlQUFTRSxTQUFTLENBQUMsQ0FBQyxxQkFBcUJFLE1BQU0sQ0FBQyxJQUFJLEdBQUcsQ0FBQztBQUFBLElBQzFELE9BQU87QUFDTEosZUFBU0UsU0FBUyxDQUFDLENBQUMsK0JBQStCLENBQUM7QUFBQSxJQUN0RDtBQUFBLEVBQ0Y7QUFFQSxXQUFTTSxXQUFXSixPQUFpQjtBQUNuQyxVQUFNVSxXQUFXVixNQUFNLENBQUM7QUFDeEIsUUFBSSxDQUFDQSxNQUFNLENBQUMsR0FBRztBQUNiSixlQUFTRSxTQUFTLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQztBQUM3QztBQUFBLElBQ0Y7QUFHQSxVQUFNYSxpQkFBaUJ2QixXQUFXWSxNQUFNLENBQUMsQ0FBQztBQUcxQyxRQUFJVyxnQkFBZ0I7QUFDbEJmLGVBQVNFLFNBQVMsQ0FBQyxDQUFDLGVBQWVZLFdBQVcsc0JBQXNCLENBQUM7QUFDckVmLGtCQUFZZSxRQUFRO0FBQUEsSUFDdEIsT0FBTztBQUVMZCxlQUFTRSxTQUFTLENBQUMsQ0FBQyxZQUFZWSxXQUFXLG1CQUFtQixDQUFDO0FBQUEsSUFDakU7QUFBQSxFQUNGO0FBRUEsV0FBU0wsYUFBYTtBQUNwQixRQUFJWCxVQUFVO0FBQ1pFLGVBQVNFLFNBQVNWLFdBQVdNLFFBQVE7QUFBQSxJQUN2QyxPQUFPO0FBQ0xFLGVBQVNFLFNBQVMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDO0FBQUEsSUFDNUM7QUFBQSxFQUNGO0FBRUEsV0FBU1EsYUFBYU4sT0FBaUI7QUFDckMsUUFBSSxDQUFDQSxNQUFNLENBQUMsS0FBSyxDQUFDQSxNQUFNLENBQUMsR0FBRztBQUMxQkosZUFBU0UsU0FBUyxDQUFDLENBQUMsZ0NBQWdDLENBQUM7QUFDckQ7QUFBQSxJQUNGO0FBQ0EsVUFBTWMsTUFBTUMsS0FBS0MsVUFBVSxDQUFDZCxNQUFNLENBQUMsR0FBR0EsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUMvQyxRQUFJTixVQUFVO0FBQ1osWUFBTXFCLFlBQVk1QixRQUFRTyxRQUFRO0FBQ2xDLFVBQUlrQixPQUFPRyxXQUFXO0FBQ3BCLFlBQUlBLFVBQVVILEdBQUcsRUFBRUksVUFBVSxHQUFHO0FBQzlCcEIsbUJBQVNFLFNBQVMsQ0FDaEIsQ0FBQyxXQUFXRSxNQUFNLENBQUMsSUFBSSwwQkFBMEJBLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFBQSxRQUU5RCxPQUFPO0FBQ0pKLG1CQUFTRSxTQUFTaUIsVUFBVUgsR0FBRztBQUFBLFFBQ2xDO0FBQUEsTUFDRixPQUFPO0FBQ0xoQixpQkFBU0UsU0FBUyxDQUNoQixDQUFDLG9CQUFvQkUsTUFBTSxDQUFDLElBQUksT0FBT0EsTUFBTSxDQUFDLElBQUksY0FBYyxDQUFDO0FBQUEsTUFFckU7QUFBQSxJQUNGLE9BQU87QUFDTEosZUFBU0UsU0FBUyxDQUFDLENBQUMsc0NBQXNDLENBQUM7QUFBQSxJQUM3RDtBQUFBLEVBQ0Y7QUFNQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUtiO0FBQUEsMkJBQUMsY0FDQztBQUFBLDZCQUFDLFlBQU8sZ0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QjtBQUFBLE1BQ3hCLHVCQUFDLG1CQUNDLE9BQU9OLGVBQ1AsVUFBVUMsa0JBQ1YsV0FBVyxtQkFIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRzZCO0FBQUEsU0FML0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFDQSx1QkFBQyxZQUFPLFNBQVMsTUFBTU0sYUFBYVAsYUFBYSxHQUFHLHNCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBEO0FBQUEsT0FiNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWNBO0FBRUo7QUFBQ0QsR0F4SGVGLFdBQVM7QUFBQTRCLEtBQVQ1QjtBQUFTLElBQUE0QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJDb250cm9sbGVkSW5wdXQiLCJqc29uTWFwIiwibW9ja2VkSnNvbiIsIlJFUExJbnB1dCIsInByb3BzIiwiX3MiLCJjb21tYW5kU3RyaW5nIiwic2V0Q29tbWFuZFN0cmluZyIsImZpbGVwYXRoIiwic2V0RmlsZXBhdGgiLCJuZXdFbnRyeSIsImNvbW1hbmQiLCJvdXRwdXQiLCJoYW5kbGVTdWJtaXQiLCJ3b3JkcyIsInNwbGl0IiwidG9Mb3dlckNhc2UiLCJoYW5kbGVNb2RlIiwiaGFuZGxlTG9hZCIsImhhbmRsZVZpZXciLCJoYW5kbGVTZWFyY2giLCJzZXRIaXN0b3J5IiwiaGlzdG9yeSIsInNldE1vZGUiLCJmaWxlUGF0aCIsIm1vY2tlZFJlc3BvbnNlIiwia2V5IiwiSlNPTiIsInN0cmluZ2lmeSIsIm1vY2tlZE1hcCIsImxlbmd0aCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTElucHV0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgJy4uL3N0eWxlcy9tYWluLmNzcyc7XG5pbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24sIHVzZVN0YXRlfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBDb250cm9sbGVkSW5wdXQgfSBmcm9tICcuL0NvbnRyb2xsZWRJbnB1dCc7XG5pbXBvcnQgeyBqc29uTWFwLCBtb2NrZWRKc29uIH0gZnJvbSAnLi4vLi4vbW9jay1kYXRhL21vY2tlZEpzb24nO1xuaW1wb3J0IHsgRW50cnkgfSBmcm9tIFwiLi9SRVBMSGlzdG9yeVwiO1xuaW1wb3J0IHsganNvbiB9IGZyb20gJ3N0cmVhbS9jb25zdW1lcnMnO1xuXG5pbnRlcmZhY2UgUkVQTElucHV0UHJvcHN7XG4gIC8vIFRPRE86IEZpbGwgdGhpcyB3aXRoIGRlc2lyZWQgcHJvcHMuLi4gTWF5YmUgc29tZXRoaW5nIHRvIGtlZXAgdHJhY2sgb2YgdGhlIHN1Ym1pdHRlZCBjb21tYW5kc1xuICAvLyBDSEFOR0VEXG4gIGhpc3Rvcnk6IEVudHJ5W10sXG4gIHNldEhpc3Rvcnk6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPEVudHJ5W10+PixcblxuICBtb2RlOiBib29sZWFuLFxuICBzZXRNb2RlOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxib29sZWFuPj4sXG59XG4vLyBZb3UgY2FuIHVzZSBhIGN1c3RvbSBpbnRlcmZhY2Ugb3IgZXhwbGljaXQgZmllbGRzIG9yIGJvdGghIEFuIGFsdGVybmF0aXZlIHRvIHRoZSBjdXJyZW50IGZ1bmN0aW9uIGhlYWRlciBtaWdodCBiZTpcbi8vIFJFUExJbnB1dChoaXN0b3J5OiBzdHJpbmdbXSwgc2V0SGlzdG9yeTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248c3RyaW5nW10+PilcbmV4cG9ydCBmdW5jdGlvbiBSRVBMSW5wdXQocHJvcHMgOiBSRVBMSW5wdXRQcm9wcykge1xuICAvLyBSZW1lbWJlcjogbGV0IFJlYWN0IG1hbmFnZSBzdGF0ZSBpbiB5b3VyIHdlYmFwcC5cbiAgLy8gTWFuYWdlcyB0aGUgY29udGVudHMgb2YgdGhlIGlucHV0IGJveFxuICBjb25zdCBbY29tbWFuZFN0cmluZywgc2V0Q29tbWFuZFN0cmluZ10gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiXCIpO1xuICBjb25zdCBbZmlsZXBhdGgsIHNldEZpbGVwYXRoXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XG4gIGNvbnN0IG5ld0VudHJ5ID0ge1xuICAgIGNvbW1hbmQ6IGNvbW1hbmRTdHJpbmcsXG4gICAgb3V0cHV0OiBbW1wiXCJdXSxcbiAgfTtcblxuICAvLyBUaGlzIGZ1bmN0aW9uIGlzIHRyaWdnZXJlZCB3aGVuIHRoZSBidXR0b24gaXMgY2xpY2tlZC5cbiAgZnVuY3Rpb24gaGFuZGxlU3VibWl0KGNvbW1hbmRTdHJpbmc6IHN0cmluZykge1xuXG4gICAgY29uc3Qgd29yZHMgPSBjb21tYW5kU3RyaW5nLnNwbGl0KFwiIFwiKTtcblxuICAgIC8vY2hlY2tzIGlmIHRoZSBmaXJzdCB3b3JkIGlzIGxvYWQgYW5kIGlmIHRoZSBhIGZpbGVwYXRoIGlzIHByb3ZpZGVkXG4gICAgaWYgKHdvcmRzWzBdLnRvTG93ZXJDYXNlKCkgPT09IFwibW9kZVwiKSB7XG4gICAgICBoYW5kbGVNb2RlKHdvcmRzKTtcbiAgICB9IGVsc2UgaWYgKHdvcmRzWzBdLnRvTG93ZXJDYXNlKCkgPT09IFwibG9hZF9maWxlXCIpIHtcbiAgICAgIGhhbmRsZUxvYWQod29yZHMpO1xuICAgIH0gZWxzZSBpZiAod29yZHNbMF0udG9Mb3dlckNhc2UoKSA9PT0gXCJ2aWV3XCIpIHtcbiAgICAgIGhhbmRsZVZpZXcoKTtcbiAgICB9IGVsc2UgaWYgKHdvcmRzWzBdLnRvTG93ZXJDYXNlKCkgPT09IFwic2VhcmNoXCIpIHtcbiAgICAgIGhhbmRsZVNlYXJjaCh3b3Jkcyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIG5ld0VudHJ5Lm91dHB1dCA9IFtbXCJQbGVhc2UgZW50ZXIgYSB2YWxpZCBjb21tYW5kLlwiXV1cbiAgICB9XG4gICAgcHJvcHMuc2V0SGlzdG9yeShbLi4ucHJvcHMuaGlzdG9yeSwgbmV3RW50cnldKTtcbiAgICBzZXRDb21tYW5kU3RyaW5nKFwiXCIpO1xuICB9XG5cbiAgZnVuY3Rpb24gaGFuZGxlTW9kZSh3b3Jkczogc3RyaW5nW10pIHtcbiAgICBpZiAoIXdvcmRzWzFdKSB7XG4gICAgICBuZXdFbnRyeS5vdXRwdXQgPSBbW1wiUGxlYXNlIGVudGVyIG1vZGUuXCJdXTtcbiAgICB9IGVsc2UgaWYgKHdvcmRzWzFdID09PSBcImJyaWVmXCIpIHtcbiAgICAgIHByb3BzLnNldE1vZGUodHJ1ZSk7XG4gICAgICBuZXdFbnRyeS5vdXRwdXQgPSBbW1wiTW9kZSBjaGFuZ2VkIHRvIFwiICsgd29yZHNbMV0gKyBcIi5cIl1dO1xuICAgIH0gZWxzZSBpZiAod29yZHNbMV0gPT0gXCJ2ZXJib3NlXCIpIHtcbiAgICAgIHByb3BzLnNldE1vZGUoZmFsc2UpO1xuICAgICAgbmV3RW50cnkub3V0cHV0ID0gW1tcIk1vZGUgY2hhbmdlZCB0byBcIiArIHdvcmRzWzFdICsgXCIuXCJdXTtcbiAgICB9IGVsc2Uge1xuICAgICAgbmV3RW50cnkub3V0cHV0ID0gW1tcIlBsZWFzZSBlbnRlciBhIHZhbGlkIGNvbW1hbmQuXCJdXTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBoYW5kbGVMb2FkKHdvcmRzOiBzdHJpbmdbXSkge1xuICAgIGNvbnN0IGZpbGVQYXRoID0gd29yZHNbMV07XG4gICAgaWYgKCF3b3Jkc1sxXSkge1xuICAgICAgbmV3RW50cnkub3V0cHV0ID0gW1tcIlBsZWFzZSBlbnRlciBmaWxlcGF0aC5cIl1dO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vUmV0cmlldmUgdGhlIG1vY2sgcmVzcG9uc2UgZm9yIHRoZSBzcGVjaWZpZWQgZmlsZSBwYXRoIGZyb20gbW9ja2VkSnNvblxuICAgIGNvbnN0IG1vY2tlZFJlc3BvbnNlID0gbW9ja2VkSnNvblt3b3Jkc1sxXV07XG5cbiAgICAvL2NoZWNrcyB0byBzZWUgbW9ja2VkUmVzcG9uc2UgaGFzIGEgdmFsdWVcbiAgICBpZiAobW9ja2VkUmVzcG9uc2UpIHtcbiAgICAgIG5ld0VudHJ5Lm91dHB1dCA9IFtbXCJDU1YgZmlsZTogXCIgKyBmaWxlUGF0aCArIFwiIGxvYWRlZCBzdWNjZXNzZnVsbHlcIl1dO1xuICAgICAgc2V0RmlsZXBhdGgoZmlsZVBhdGgpO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBpZiBtb2NrZWRSZXNwb25zZSBkb2VzIG5vdCBoYXZlIGEgdmFsdWVcbiAgICAgIG5ld0VudHJ5Lm91dHB1dCA9IFtbXCJFcnJvcjogXCIgKyBmaWxlUGF0aCArIFwiIGNhbm5vdCBiZSBsb2FkZWRcIl1dO1xuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIGhhbmRsZVZpZXcoKSB7XG4gICAgaWYgKGZpbGVwYXRoKSB7XG4gICAgICBuZXdFbnRyeS5vdXRwdXQgPSBtb2NrZWRKc29uW2ZpbGVwYXRoXTtcbiAgICB9IGVsc2Uge1xuICAgICAgbmV3RW50cnkub3V0cHV0ID0gW1tcIk5lZWQgdG8gbG9hZCBmaXJzdC5cIl1dO1xuICAgIH1cbiAgfSAvLyB0YWtlbiBmcm9tIGh0dHBzOi8vc3RhY2tvdmVyZmxvdy5jb20vcXVlc3Rpb25zLzE1MTY0NjU1L2dlbmVyYXRlLWh0bWwtdGFibGUtZnJvbS0yZC1qYXZhc2NyaXB0LWFycmF5XG5cbiAgZnVuY3Rpb24gaGFuZGxlU2VhcmNoKHdvcmRzOiBzdHJpbmdbXSkge1xuICAgIGlmICghd29yZHNbMV0gfHwgIXdvcmRzWzJdKSB7XG4gICAgICBuZXdFbnRyeS5vdXRwdXQgPSBbW1wiUGxlYXNlIGVudGVyIGNvbHVtbiBhbmQgdmFsdWUuXCJdXTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3Qga2V5ID0gSlNPTi5zdHJpbmdpZnkoW3dvcmRzWzFdLCB3b3Jkc1syXV0pO1xuICAgIGlmIChmaWxlcGF0aCkge1xuICAgICAgY29uc3QgbW9ja2VkTWFwID0ganNvbk1hcFtmaWxlcGF0aF07XG4gICAgICBpZiAoa2V5IGluIG1vY2tlZE1hcCkge1xuICAgICAgICBpZiAobW9ja2VkTWFwW2tleV0ubGVuZ3RoID09IDApIHtcbiAgICAgICAgICBuZXdFbnRyeS5vdXRwdXQgPSBbXG4gICAgICAgICAgICBbXCJWYWx1ZSBcIiArIHdvcmRzWzJdICsgXCIgbm90IGZvdW5kIGluIGNvbHVtbiBcIiArIHdvcmRzWzFdXSxcbiAgICAgICAgICBdO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICBuZXdFbnRyeS5vdXRwdXQgPSBtb2NrZWRNYXBba2V5XTtcbiAgICAgICAgfSBcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG5ld0VudHJ5Lm91dHB1dCA9IFtcbiAgICAgICAgICBbXCJJbnZhbGlkIGlucHV0cyBcIiArIHdvcmRzWzFdICsgXCIsIFwiICsgd29yZHNbMl0gKyBcIiBmb3Igc2VhcmNoLlwiXSxcbiAgICAgICAgXTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgbmV3RW50cnkub3V0cHV0ID0gW1tcIk5lZWQgdG8gbG9hZCBmaXJzdCBiZWZvcmUgc2VhcmNoaW5nLlwiXV07XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFdlIHN1Z2dlc3QgYnJlYWtpbmcgZG93biB0aGlzIGNvbXBvbmVudCBpbnRvIHNtYWxsZXIgY29tcG9uZW50cywgdGhpbmsgYWJvdXQgdGhlIGluZGl2aWR1YWwgcGllY2VzXG4gICAqIG9mIHRoZSBSRVBMIGFuZCBob3cgdGhleSBjb25uZWN0IHRvIGVhY2ggb3RoZXIuLi5cbiAgICovXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWlucHV0XCI+XG4gICAgICB7LyogVGhpcyBpcyBhIGNvbW1lbnQgd2l0aGluIHRoZSBKU1guIE5vdGljZSB0aGF0IGl0J3MgYSBUeXBlU2NyaXB0IGNvbW1lbnQgd3JhcHBlZCBpblxuICAgICAgICAgICAgYnJhY2VzLCBzbyB0aGF0IFJlYWN0IGtub3dzIGl0IHNob3VsZCBiZSBpbnRlcnByZXRlZCBhcyBUeXBlU2NyaXB0ICovfVxuICAgICAgey8qIEkgb3B0ZWQgdG8gdXNlIHRoaXMgSFRNTCB0YWc7IHlvdSBkb24ndCBuZWVkIHRvLiBJdCBzdHJ1Y3R1cmVzIG11bHRpcGxlIGlucHV0IGZpZWxkc1xuICAgICAgICAgICAgaW50byBhIHNpbmdsZSB1bml0LCB3aGljaCBtYWtlcyBpdCBlYXNpZXIgZm9yIHNjcmVlbnJlYWRlcnMgdG8gbmF2aWdhdGUuICovfVxuICAgICAgPGZpZWxkc2V0PlxuICAgICAgICA8bGVnZW5kPkVudGVyIGEgY29tbWFuZDo8L2xlZ2VuZD5cbiAgICAgICAgPENvbnRyb2xsZWRJbnB1dFxuICAgICAgICAgIHZhbHVlPXtjb21tYW5kU3RyaW5nfVxuICAgICAgICAgIHNldFZhbHVlPXtzZXRDb21tYW5kU3RyaW5nfVxuICAgICAgICAgIGFyaWFMYWJlbD17XCJDb21tYW5kIGlucHV0XCJ9XG4gICAgICAgIC8+XG4gICAgICA8L2ZpZWxkc2V0PlxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZyl9PlN1Ym1pdDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApO1xufSJdLCJmaWxlIjoiL1VzZXJzL3NlZWhhbmFodGFuZy9EZXNrdG9wL2NzL2NzMzIvbW9jay1yamVjcm9pMS1zdGFuZzUyL3NyYy9jb21wb25lbnRzL1JFUExJbnB1dC50c3gifQ==