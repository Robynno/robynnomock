export default [
	[
		"Barrington",
		"130,455.00",
		"154,441.00",
		"69,917.00"
	]
];