import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPL.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8612ede7"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPL.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8612ede7"; const useState = __vite__cjsImport3_react["useState"];
import "/src/styles/main.css?t=1697174494758";
import { REPLHistory } from "/src/components/REPLHistory.tsx?t=1697174494756";
import { REPLInput } from "/src/components/REPLInput.tsx?t=1697224057500";
export default function REPL() {
  _s();
  const [history, setHistory] = useState([]);
  const [mode, setMode] = useState(true);
  return /* @__PURE__ */ jsxDEV("div", { className: "repl", children: [
    /* @__PURE__ */ jsxDEV(REPLHistory, { history, mode }, void 0, false, {
      fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPL.tsx",
      lineNumber: 24,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
      fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPL.tsx",
      lineNumber: 25,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(REPLInput, { history, setHistory, mode, setMode }, void 0, false, {
      fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPL.tsx",
      lineNumber: 27,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPL.tsx",
    lineNumber: 20,
    columnNumber: 10
  }, this);
}
_s(REPL, "EE/+zzCPWE/UN2RrvKW7VIHPOrg=");
_c = REPL;
var _c;
$RefreshReg$(_c, "REPL");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/seehanahtang/Desktop/cs/cs32/mock-rjecroi1-stang52/src/components/REPL.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZCTixTQUFTQSxnQkFBZ0I7QUFDekIsT0FBTztBQUNQLFNBQVNDLG1CQUEwQjtBQUNuQyxTQUFTQyxpQkFBaUI7QUFXMUIsd0JBQXdCQyxPQUFPO0FBQUFDLEtBQUE7QUFDN0IsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlOLFNBQWtCLEVBQUU7QUFDbEQsUUFBTSxDQUFDTyxNQUFNQyxPQUFPLElBQUlSLFNBQWtCLElBQUk7QUFFOUMsU0FDRSx1QkFBQyxTQUFJLFdBQVUsUUFJYjtBQUFBLDJCQUFDLGVBQVksU0FBbUIsUUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QztBQUFBLElBQzdDLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFJO0FBQUEsSUFFSix1QkFBQyxhQUFVLFNBQWtCLFlBQ2xCLE1BQVksV0FEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUN3QztBQUFBLE9BUjFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTQTtBQUVKO0FBQUNJLEdBaEJ1QkQsTUFBSTtBQUFBTSxLQUFKTjtBQUFJLElBQUFNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlJFUExIaXN0b3J5IiwiUkVQTElucHV0IiwiUkVQTCIsIl9zIiwiaGlzdG9yeSIsInNldEhpc3RvcnkiLCJtb2RlIiwic2V0TW9kZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgJy4uL3N0eWxlcy9tYWluLmNzcyc7XG5pbXBvcnQgeyBSRVBMSGlzdG9yeSwgRW50cnkgfSBmcm9tICcuL1JFUExIaXN0b3J5JztcbmltcG9ydCB7IFJFUExJbnB1dCB9IGZyb20gJy4vUkVQTElucHV0JztcblxuLyogXG4gIFlvdSdsbCB3YW50IHRvIGV4cGFuZCB0aGlzIGNvbXBvbmVudCAoYW5kIG90aGVycykgZm9yIHRoZSBzcHJpbnRzISBSZW1lbWJlciBcbiAgdGhhdCB5b3UgY2FuIHBhc3MgXCJwcm9wc1wiIGFzIGZ1bmN0aW9uIGFyZ3VtZW50cy4gSWYgeW91IG5lZWQgdG8gaGFuZGxlIHN0YXRlIFxuICBhdCBhIGhpZ2hlciBsZXZlbCwganVzdCBtb3ZlIHVwIHRoZSBob29rcyBhbmQgcGFzcyB0aGUgc3RhdGUvc2V0dGVyIGFzIGEgcHJvcC5cbiAgXG4gIFRoaXMgaXMgYSBncmVhdCB0b3AgbGV2ZWwgY29tcG9uZW50IGZvciB0aGUgUkVQTC4gSXQncyBhIGdvb2QgaWRlYSB0byBoYXZlIG9yZ2FuaXplIGFsbCBjb21wb25lbnRzIGluIGEgY29tcG9uZW50IGZvbGRlci5cbiAgWW91IGRvbid0IG5lZWQgdG8gZG8gdGhhdCBmb3IgdGhpcyBnZWFydXAuXG4qL1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBSRVBMKCkge1xuICBjb25zdCBbaGlzdG9yeSwgc2V0SGlzdG9yeV0gPSB1c2VTdGF0ZTxFbnRyeVtdPihbXSlcbiAgY29uc3QgW21vZGUsIHNldE1vZGVdID0gdXNlU3RhdGU8Ym9vbGVhbj4odHJ1ZSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlcGxcIj4gIFxuICAgICAgey8qVGhpcyBpcyB3aGVyZSB5b3VyIFJFUExIaXN0b3J5IG1pZ2h0IGdvLi4uIFlvdSBhbHNvIG1heSBjaG9vc2UgdG8gYWRkIGl0IHdpdGhpbiB5b3VyIFJFUExJbnB1dCBcbiAgICAgIGNvbXBvbmVudCBvciBzb21ld2hlcmUgZWxzZSBkZXBlbmRpbmcgb24geW91ciBjb21wb25lbnQgb3JnYW5pemF0aW9uLiBXaGF0IGFyZSB0aGUgcHJvcyBhbmQgY29ucyBvZiBlYWNoPyAqL31cbiAgICAgIHsvKiBDSEFOR0VEICovfVxuICAgICAgPFJFUExIaXN0b3J5IGhpc3RvcnkgPXtoaXN0b3J5fSBtb2RlID0ge21vZGV9Lz5cbiAgICAgIDxocj48L2hyPlxuXG4gICAgICA8UkVQTElucHV0IGhpc3Rvcnk9e2hpc3Rvcnl9IHNldEhpc3Rvcnk9e3NldEhpc3Rvcnl9XG4gICAgICAgICAgICAgICAgIG1vZGU9e21vZGV9IHNldE1vZGU9e3NldE1vZGV9Lz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3NlZWhhbmFodGFuZy9EZXNrdG9wL2NzL2NzMzIvbW9jay1yamVjcm9pMS1zdGFuZzUyL3NyYy9jb21wb25lbnRzL1JFUEwudHN4In0=