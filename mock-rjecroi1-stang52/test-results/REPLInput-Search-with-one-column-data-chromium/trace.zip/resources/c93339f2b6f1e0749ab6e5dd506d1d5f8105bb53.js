export default [
	[
		"70667",
		"Proxima Centauri",
		"-0.47175",
		"-0.36132",
		"-1.15037"
	]
];